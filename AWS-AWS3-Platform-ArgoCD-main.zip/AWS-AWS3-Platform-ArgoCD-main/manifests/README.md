# Manifests
This directory is used to store custom Kubernetes manifests for our EKS clusters. This should only be used for very simple manifests. Our preference is to use Helm.