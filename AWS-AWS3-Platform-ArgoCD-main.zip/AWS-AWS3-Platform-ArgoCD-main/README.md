# AWS-AWS3-Platform-ArgoCD

##  Introduction
This repository is used to store the Plaform Engineering Kubernetes cluster addons. This repository works in conjunction with the AWS-AWS3-terraform-aws-eks repository. The AWS-AWS3-terraform-aws-eks repository creates an ApplicationSet which creates an initial bootstrap application of this repository. The addons on this repository are enabled by passing in labels to the `in-cluster` Kubernetes secret. This is performed via Terraform and then ArgoCD will conditionally create applications based off the labels of this secret. Annotations on this secret are also used to pass information from Terraform to ArgoCD so that downstream applications in this repository can retrieve information for resources created by Terraform.

The addons in this repository are used for management of Kubernetes, this is not used to deploy feature team applications.

## Permissions

Permissions for ArgoCD to access GitHub repositories is being performed via OIDC and a GitHub app. This is configured via Terraform and put in a Kubernetes secret in the argocd namespace called `declaritive-creds`. This contains details of the GitHub App being used for authenticating ArgoCD to GitHub. This information is created in AWS Secrets Manager as part of the Bootstrap process for the AWS Account. The GitHub App with the `githubAppInstallationID` in the `declaritive-creds` secret must be configured to have access to any private repositories being referenced here and downstream by applications. Platform Engineering can set this access up. If you need to grant this App additional repositories, contact Platform Engineering.

## Applications

Currently this repository allows the deployment of the below ArgoCD applications. All of the below applications have been tested:
- ArgoCD (this will bootstrap itself)
- AWS Load Balancer Controller
- External-DNS
- External-Secrets

The following can also be deployed and is ready for testing however complete testing has not been performed and we will need a Feature Team to confirm this is working as expected:
- Istio

The following can also be deployed but are not currently ready for consumption:
- Lacework Linux Agent
- Lacework Admission Controller
- VPC Custom Networking

The following is being developed:
- JFrog Passwordless Access for Amazon EKS - this will replace the `Tactical Image Pull Secrets` functionality

## Features
There are a number of features provided with this ArgoCD configuration which are not direct applications. Features available are as follows:

- Application Bootstrapping
- Creation of Namespaces
- Creation of ArgoCD AppProjects
- Tactical Image Pull Secrets
- External-Secrets ClusterSecretStore Usage
- Tactical Image Pull Secrets
- EBS Persistent Volumes

### Creation of ArgoCD AppProjects
#### Prerequisites
You must have deployed an EKS cluster using the `AWS-AWS3-terraform-aws-eks` module and passed in values for the following:
- `application_argocd_addons_url` - this value would be the GitHub URL for the repository hosting your application config. That would be this repository in this scenario.
- `application_argocd_addons_branch`- this value is the Git branch you want to ArgoCD to use.
- `enable_application_configuration` - this will allow you to create ArgoCD AppProjects

Your application repository must have at least one of the files in the following paths:
    - `values/cluster/in-cluster/values.yaml`
    - `values/default/values.yaml` - these values will be deployed onto all clusters
    - `values/environment/{{metadata.labels.environment}}/values.yaml` - these values will be deployed just on the environment the `{{metadata.labels.environment}}` equates to. This value is set by passing the `environment` Terraform variable into the `AWS-AWS3-terraform-aws-eks` Terraform module.

You can use any mix of the above to pass in values. 


#### Usage

The syntax for the required values for the above is like below:

```
applicationAppProjects:
  - name: ${APP_PROJECT_NAME}
    applicationSourceRepos: 
      - '${APP_PROJECT_REPOSITORY}'
```

As these values are passed into Helm you can set values in multiple files.

### Creation of Application Namespaces and SecretStore's to pull AWS Secrets Manager Secrets
#### Prerequisites
- `application_namespaces` - You must have set the application_namespaces variable in your .tfvars file when calling the `AWS-AWS3-terraform-aws-eks` Terraform module and creating the EKS cluster. Before this value could be provided from your own repository by providing a values.yaml file in a certain directory but this has since changed to introduce new functionality. Appliction_namespaces has been updated to become a map of objects since module version v1.0.0 where each namespace can provide its own configuration. Application_namespaces supports the following values nested in each namespace key:
- `secrets_manager_access` - Enables an application namespace below to access AWS Secrets Manager secrets according to the below pattern. This is a boolean value in terraform and so is set to either true or false (set to false if the value is not specified in the map).
- `bedrock_foundational_model_product_ids` - A list of third party product id's which correspond to a specific third party bedrock foundational model. The id is needed in permissions to perform a aws-marketplace:subscribe on the id so that it can be enabled. Note: Amazon provided bedrock foundational models do not require this
- `s3_bucket_names` - A list of existing s3 bucket names which when provided will give the namespace permissions to perform CRUD operations on said bucket(s).
- `enable_application_configuration` - A bool which must be set to true which both enables terraform and argo to create the required resources to correctly deploy an application namespace and corresponding secretstore
- `configure AWS Secrets Manager Naming Pattern` - To give the correct access to AWS Secrets Manager Secrets for each namespace the secrets in AWS Secrets Manager must be named folliwng a pattern. The pattern is `eks/<eks_cluster_name/application_namespace_name/secret_name` for example if you are deploying to an EKS cluster with the name dummydev and the application namespace name is app1, the pattern would be `eks/dummydev/app1/secret_name`.

#### Usage

application_namespace            = {
  "app1" = {
    secrets_manager_access                 = true
    s3_bucket_names                        = ["test1", "test2"]
    bedrock_foundational_model_product_ids = ["prod-ozonys2hmmpeu", "prod-6dw3qvchef7zy"]
    },
  "app2" = {
    s3_bucket_names                        = ["test1", "test2"]
    bedrock_foundational_model_product_ids = ["prod-ozonys2hmmpeu", "prod-6dw3qvchef7zy"]
    },
  "app3" = {
    secrets_manager_access                 = true
    }
}

enable_application_configuration = true
```

The above would create and bootstrap three namespaces, app1, app2 and app3. In this example, app1 would have access to secrets manager secrets following the enforced pattern, perform CRUD operations on the s3 buckets named test1 and test 2 and make use of the bedrock foundational models which correspond to the product ids prod-ozonys2hmmpeu and prod-6dw3qvchef7zy.  

All the inputs inside the namespace key in the application_namepspaces variable are optional so that as the variable grows it's configuration can be kept clean.

### Application Bootstrapping
#### Prerequisites
You must have deployed an EKS cluster using the `AWS-AWS3-terraform-aws-eks` module and passed in values for the following:
- `application_argocd_addons_url` - this value would be the GitHub URL for the repository hosting your application config. That would be this repository in this scenario.
- `application_argocd_addons_branch`- this value is the Git branch you want to ArgoCD to use.
- `application_argocd_addons_path` - this value is the path to your initial bootstrap application/applications. This will recursively look in the path to find valid ArgoCD Applications.
- `enable_applications` - this will enable the ApplicationSet which will target your application teams ArgoCD Applications/ApplicationSets

#### Usage

You must also be targetting a valid AppProject. In order to create an AppProject you must have created one using the `Creation of ArgoCD AppProjects` process. You cannot deploy into the `default` ArgoCD AppProject.

Your applications must be being deployed into a valid namespace, these can be created using the `Creation of Namespaces` process.

Your ArgoCD Applications must also be using HTTPS for any access to repositories. Authentication for access to repositories is handled by Terraform and Platform Engineering.


### Tactical Image Pull Secrets
#### Prerequisites
You must have deployed an EKS cluster using the `AWS-AWS3-terraform-aws-eks` module and passed in values for the following:
- `enable_external_secrets` - external-secrets is used to pull the Image Pull Secret from AWS Secrets Manager
- `application_argocd_addons_url` - this value would be the GitHub URL for the repository hosting your application config. That would be this repository in this scenario.
- `application_argocd_addons_branch`- this value is the Git branch you want to ArgoCD to use.
- `enable_tactical_shared_imagepullsecret` - this enables this functionality

Your application repository must have at least one of the files in the following paths:
- `values/cluster/in-cluster/values.yaml`
- `values/default/values.yaml` - these values will be deployed onto all clusters
- `values/environment/{{metadata.labels.environment}}/values.yaml` - these values will be deployed just on the environment the `{{metadata.labels.environment}}` equates to. This value is set by passing the `environment` Terraform variable into the `AWS-AWS3-terraform-aws-eks` Terraform module.

Platform Engineering must have configured the AWS Secrets Manager Secret called `jfrog-eks-tactical-imagepullsecret` in the same AWS account being deployed into.

#### Usage

The syntax for the required values for the above is like below:

```
applicationNamespaces:
  - "${NAMESPACE_NAME}"
```

This will then deploy a secret in all Kubernetes namespaces called `jfrog-image-pull-secret`. You must ensure all of your application namespaces are being captured in the `applicationNamespaces` value.

### External-Secrets ClusterSecretStore Usage
#### Prerequisites
You must have deployed an EKS cluster using the `AWS-AWS3-terraform-aws-eks` module and passed in values for the following:
- `enable_external_secrets` - external-secrets is used to pull the Image Pull Secret from AWS Secrets Manager

#### Usage

Currently the only service to use this is the tactical Image Pull Secret mechanism. However, dependent on if feature teams want this functionality we can make this available for feature teams to use as well.

### EBS Persistent Volumes Usage
#### Prerequisites
You must have deployed an EKS cluster using the `AWS-AWS3-terraform-aws-eks` module and passed in values for the following:
- `enable_ebs_csi_driver` - this will enable the EBS CSI driver

#### Usage

This will currently provision a gp2 and gp3 storage class which is encrypted using a customer managed KMS key. You should use gp3 unless you have an explicit requirement for gp3.

