# Default
This is a placeholder directory if we wanted to move into having ArgoCD to manage different named clusters and have the ability to pass in values that all clusters would use.