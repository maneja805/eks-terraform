# tf-aws-cert-manager
## Introduction
This sub-module is used to deploy cert-manager on the standard EKS module.
cert-manager, a secrets management tool specific to kubernetes/EKS should not be confused with ACM (AWS Certificate Manager)