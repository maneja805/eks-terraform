# tf-aws-cert-manager
## Introduction
This sub-module is used to deploy cert-manager on the standard EKS module.
cert-manager, a secrets management tool specific to kubernetes/EKS should not be confused with ACM (AWS Certificate Manager)


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cert_manager_service_account"></a> [cert\_manager\_service\_account](#input\_cert\_manager\_service\_account) | Service account name for the cert-manager | `string` | `"cert-manager"` | no |
| <a name="input_certificate_authority_arn"></a> [certificate\_authority\_arn](#input\_certificate\_authority\_arn) | The AWS PCA for signing private certificates. | `string` | `"arn:aws:acm-pca:eu-west-2:091635179671:certificate-authority/c969bdd4-6f2c-4bc5-8ef3-de4382cef2ab"` | no |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | A Custom name for the EKS cluster | `string` | n/a | yes |
| <a name="input_oidc_provider_arn"></a> [oidc\_provider\_arn](#input\_oidc\_provider\_arn) | OIDC provider ARN associated with EKS cluster | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | AWS region where resources are spinned up | `string` | n/a | yes |
## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_cert_manager_irsa"></a> [cert\_manager\_irsa](#module\_cert\_manager\_irsa) | terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks | n/a |
## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cert_manager_role_arn"></a> [cert\_manager\_role\_arn](#output\_cert\_manager\_role\_arn) | Cert Manager IRSA role ARN |
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
## Requirements

No requirements.
## Resources

| Name | Type |
|------|------|
| [aws_iam_policy.cert_manager_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source | 