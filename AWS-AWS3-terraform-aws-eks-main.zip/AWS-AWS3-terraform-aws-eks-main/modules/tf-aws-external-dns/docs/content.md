# tf-aws-external-dns
## Introduction
This sub-module is used to deploy external-dns on the standard EKS module.