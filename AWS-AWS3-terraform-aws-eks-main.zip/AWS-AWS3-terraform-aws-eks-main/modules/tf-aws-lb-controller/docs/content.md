# tf-aws-lb-controller
## Introduction
This sub-module is used to deploy the AWS Load Balancer Controller on the standard EKS module.