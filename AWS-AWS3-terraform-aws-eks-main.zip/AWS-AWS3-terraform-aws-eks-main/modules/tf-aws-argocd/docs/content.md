# tf-aws-argocd
## Introduction
This sub-module is used to deploy a ArgoCD on the standard EKS module. This has a dependency on an AWS Secrets Manager Secret called `github-auth` being in the AWS account which includes values for `github_app_id`, `github_app_installation_id` and `github_app_private_key`. This must be created in advance and is outside of this process.

This will currently bootstrap the EKS cluster specifically for platform components. The pattern for deploying the platform bootstrap should be updated to target a specific application repository for app teams to use this pattern. Conversely we could simply create an applicationset targetting their own repositories.