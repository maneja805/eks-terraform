# tf-aws-eks-application-bootstrap
## Introduction
This sub-module is used to deploy the Application Bootstrap on the standard EKS module.


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_namespaces"></a> [application\_namespaces](#input\_application\_namespaces) | The names and configuration of the namespaces the application team require | <pre>map(object({<br/>    secrets_manager_access                 = optional(bool, false)<br/>    s3_bucket_names                        = optional(list(string), [])<br/>    bedrock_foundational_model_product_ids = optional(list(string), [])<br/>  }))</pre> | n/a | yes |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | A Custom name for the EKS cluster | `string` | n/a | yes |
| <a name="input_oidc_provider_arn"></a> [oidc\_provider\_arn](#input\_oidc\_provider\_arn) | OIDC provider ARN associated with EKS cluster | `string` | n/a | yes |
## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_irsa_per_namespace"></a> [irsa\_per\_namespace](#module\_irsa\_per\_namespace) | terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks | n/a |
## Outputs

| Name | Description |
|------|-------------|
| <a name="output_secrets_manager_namespace_role_arns"></a> [secrets\_manager\_namespace\_role\_arns](#output\_secrets\_manager\_namespace\_role\_arns) | ARNs for each role created for each application namespace |
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
## Requirements

No requirements.
## Resources

| Name | Type |
|------|------|
| [aws_iam_policy.bedrock_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_policy.s3_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_policy.secrets_manager_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source | 