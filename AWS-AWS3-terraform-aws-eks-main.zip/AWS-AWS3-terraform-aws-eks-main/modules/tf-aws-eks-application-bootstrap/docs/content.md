# tf-aws-eks-application-bootstrap
## Introduction
This sub-module is used to deploy the Application Bootstrap on the standard EKS module.