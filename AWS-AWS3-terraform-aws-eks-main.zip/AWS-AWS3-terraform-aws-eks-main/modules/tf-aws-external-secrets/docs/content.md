# tf-aws-external-secrets
## Introduction
This sub-module is used to deploy External Secrets on the standard EKS module.