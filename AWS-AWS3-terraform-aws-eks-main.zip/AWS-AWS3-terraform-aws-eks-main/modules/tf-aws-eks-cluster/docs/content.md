# tf-aws-eks-cluster
## Introduction
This sub-module is used to deploy an EKS cluster on the standard EKS module.