# tf-aws-eks-cluster
## Introduction
This sub-module is used to deploy an EKS cluster on the standard EKS module.


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_ami_type"></a> [ami\_type](#input\_ami\_type) | AMI type for the node | `string` | n/a | yes |
| <a name="input_ami_version"></a> [ami\_version](#input\_ami\_version) | AMi version for the AMI from which nodes are created | `string` | n/a | yes |
| <a name="input_cloudwatch_version"></a> [cloudwatch\_version](#input\_cloudwatch\_version) | Addon version for the cloudwatch | `string` | n/a | yes |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | A Custom name for the EKS cluster | `string` | n/a | yes |
| <a name="input_cluster_security_group_additional_rules"></a> [cluster\_security\_group\_additional\_rules](#input\_cluster\_security\_group\_additional\_rules) | Additional security group rules for the EKS cluster. | <pre>map(object({<br/>    description              = string<br/>    protocol                 = string<br/>    from_port                = number<br/>    to_port                  = number<br/>    type                     = string<br/>    source_security_group_id = string<br/>  }))</pre> | `{}` | no |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Kubernetes cluster version | `string` | n/a | yes |
| <a name="input_coredns_version"></a> [coredns\_version](#input\_coredns\_version) | Addon version for the core-dns | `string` | n/a | yes |
| <a name="input_desired_size"></a> [desired\_size](#input\_desired\_size) | Desired number of nodes in the autoscaling group | `string` | n/a | yes |
| <a name="input_ebs_volume_size"></a> [ebs\_volume\_size](#input\_ebs\_volume\_size) | Size of the EBS volume for the nodes | `number` | `30` | no |
| <a name="input_enable_cloudwatch"></a> [enable\_cloudwatch](#input\_enable\_cloudwatch) | Flag to enable/disable the Cloudwatch Agent | `bool` | n/a | yes |
| <a name="input_instance_types"></a> [instance\_types](#input\_instance\_types) | Type of instance for the node group | `list(string)` | n/a | yes |
| <a name="input_kube-proxy_version"></a> [kube-proxy\_version](#input\_kube-proxy\_version) | Addon version for the kube-proxy | `string` | n/a | yes |
| <a name="input_max_size"></a> [max\_size](#input\_max\_size) | Mazximum number of nodes in the autoscaling group | `string` | n/a | yes |
| <a name="input_mgmt_cidrs"></a> [mgmt\_cidrs](#input\_mgmt\_cidrs) | n/a | `list(string)` | n/a | yes |
| <a name="input_min_size"></a> [min\_size](#input\_min\_size) | Minimum number of nodes in the autoscaling group | `string` | n/a | yes |
| <a name="input_node_group_name_prefix"></a> [node\_group\_name\_prefix](#input\_node\_group\_name\_prefix) | A prefix name for the node group | `string` | n/a | yes |
| <a name="input_node_security_group_additional_rules"></a> [node\_security\_group\_additional\_rules](#input\_node\_security\_group\_additional\_rules) | Additional security group rules for the EKS cluster nodes. | <pre>map(object({<br/>    description                   = string<br/>    protocol                      = string<br/>    from_port                     = number<br/>    to_port                       = number<br/>    type                          = string<br/>    source_cluster_security_group = bool<br/>  }))</pre> | `{}` | no |
| <a name="input_principal_arns"></a> [principal\_arns](#input\_principal\_arns) | Principle ARN of the entity(user/role) for the admin access for the cluster | `list(string)` | `[]` | no |
| <a name="input_purchase_option"></a> [purchase\_option](#input\_purchase\_option) | Purchase option for the nodes | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | AWS region where resources are spinned up | `string` | n/a | yes |
| <a name="input_runner_cidrs"></a> [runner\_cidrs](#input\_runner\_cidrs) | n/a | `list(string)` | n/a | yes |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | List of private subnets | `list(string)` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for the AWS resources to get added when the resources ois spinned up | `any` | n/a | yes |
| <a name="input_vpc-cni_version"></a> [vpc-cni\_version](#input\_vpc-cni\_version) | Addon version for the VPC-CNI | `string` | n/a | yes |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | VPC id where all AWS resources will belong to | `string` | n/a | yes |
## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_ebs_kms_key"></a> [ebs\_kms\_key](#module\_ebs\_kms\_key) | terraform-aws-modules/kms/aws | 3.1.0 |
| <a name="module_eks"></a> [eks](#module\_eks) | terraform-aws-modules/eks/aws | 20.14.0 |
## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cluster_certificate_authority_data"></a> [cluster\_certificate\_authority\_data](#output\_cluster\_certificate\_authority\_data) | EKS cluster certificate authority data |
| <a name="output_cluster_endpoint"></a> [cluster\_endpoint](#output\_cluster\_endpoint) | EKS cluster endpoint |
| <a name="output_cluster_name"></a> [cluster\_name](#output\_cluster\_name) | EKS cluster name |
| <a name="output_kms_key_arn"></a> [kms\_key\_arn](#output\_kms\_key\_arn) | The KMS Key ARN for EKS |
| <a name="output_oidc_provider"></a> [oidc\_provider](#output\_oidc\_provider) | EKS cluster provider |
| <a name="output_oidc_provider_arn"></a> [oidc\_provider\_arn](#output\_oidc\_provider\_arn) | EKS OIDC provider ARN |
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
## Requirements

No requirements.
## Resources

| Name | Type |
|------|------|
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_roles.sso_admin_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_roles) | data source | 