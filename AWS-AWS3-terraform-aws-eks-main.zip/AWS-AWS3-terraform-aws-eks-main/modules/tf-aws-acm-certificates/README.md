# tf-aws-acm-certifcate
## Introduction
This sub-module is used to create ACM certificates from PCA on the standard EKS module. This depends on the PCA certificate ARN being provided. The certificate created via this mechanism can be automatically discovered by the AWS Load Balancer Controller. This should only be used for certifcates being created for the AWS Load Balancer Controller. For certificate installed onto the cluster, use the cert-manager addon.


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_certificate_authority_arn"></a> [certificate\_authority\_arn](#input\_certificate\_authority\_arn) | ARN of the ACM PCA | `string` | n/a | yes |
| <a name="input_certificate_names"></a> [certificate\_names](#input\_certificate\_names) | List of certificate names to create under the dns\_domain | `list(string)` | n/a | yes |
| <a name="input_dns_domain"></a> [dns\_domain](#input\_dns\_domain) | The base DNS domain for the certificates | `string` | n/a | yes |
| <a name="input_early_renewal_duration"></a> [early\_renewal\_duration](#input\_early\_renewal\_duration) | Amount of time to start automatic renewal process before expiration | `string` | `"P30D"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for the AWS resources to get added when the resources ois spinned up | `map(string)` | n/a | yes |
## Modules

No modules.
## Outputs

| Name | Description |
|------|-------------|
| <a name="output_certificate_arns"></a> [certificate\_arns](#output\_certificate\_arns) | ARNs of the created ACM certificates |
| <a name="output_certificate_domains"></a> [certificate\_domains](#output\_certificate\_domains) | Domain names of the created ACM certificates |
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
## Requirements

No requirements.
## Resources

| Name | Type |
|------|------|
| [aws_acm_certificate.certificates](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate) | resource | 