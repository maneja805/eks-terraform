# tf-aws-ebs-csi-driver
## Introduction
This sub-module is used to deploy the EBS CSI driver on the standard EKS module.