# terraform-eks-module
## Introduction
This module is used to deploy a standard AWS EKS build. This will create an EKS cluster with ArgoCD installed. ArgoCD will then install cluster addons and also self manage ArgoCD. This module has been tested using the AWS-AWS3-Platform-ArgoCD repository for bootstrapping. Accessing ArgoCD can take between 5-15 minutes once the Terraform Apply has been successful. This allows suitable time for ArgoCD to bootstrap itself, create the AWS Load Balancer Controller and External-DNS. These resources are required to then allow ArgoCD to create an ingress which will then auto-discover the associated certificate for the AWS Application Load Balancer. Then it will add the appropriate Route53 record for ArgoCD. This time will then also give time for the hosted zones to propagate.

This module priortises doing Infrastructure via Terraform and using ArgoCD for cluster resources. This is enabled by Terraform doing 2 initial Helm releases. 1 is to install ArgoCD and the other is to install an ApplicationSet which then manages all of the ArgoCD addons. This is to keep as much of the Kubernetes configuration outside of Terrform. 

Addons are enabled within ArgoCD conditionally using the annotations of the cluster secret used to register the EKS cluster in ArgoCD. We use ArgoCD cluster generators to conditionally deploy addons to the EKS cluster dependent on whether the addons is enabled via these annotations.

There are a number of addons that depend on resources created via Terraform, i.e IRSA where Terraform will create the IAM role and a serviceaccount on the cluster needs the ARN. This functionality is performed by Terraform creating the AWS resources required and then storing the required information as labels  of the cluster secret used to register the EKS cluster in ArgoCD. ArgoCD ApplicationSets can then reference these values in their YAML manfiests.

The setting of annotations and labels is done using the local called `argocd`.

This Terraform module will only have submodules for products where we need to create some of their dependent resources using Terraform.

## Usage
This module is used by setting conditional boolean flags for functionality to be enabled. The products that can be enabled are:

- ArgoCD
- External-DNS
- External-Secrets
- AWS Load Balancer Controller
- Istio
- Laceworks
- Application Bootstrap
- Cert-manager
- Metrics-server

These can be enabled in your tfvars file by setting the enable values to `true`.

## Deletion
The deletion of this module is complicated due to the fact that ArgoCD will become responsible for creating AWS managed resources it means that deletion of this module depends on resources outside of its control. 

ArgoCD will use the AWS Load Balancer Controller to create a Kubernetes ingress. This will create an AWS Application Load Balancer. The ingress will also use External-DNS to create a Route53 record for the ingress. Unless these resources are destroyed in advance then this will leave resources left over and can prevent re-installing the same cluster.

We need someway of performing a cascading deletion of ArgoCD applications in the correct order before doing an automated deletion. Until then, we need to ensure that all of the AWS Application Load Balancers and Route53 records are deleted manually. This is required otherwise the ACM certificate cannot be deleted as there will be a Load Balancer still using the ACM cert.

## Upgrade instructions
- 0.6.0 to 0.7.0:
    - An engineer with access to the Terraform state will need to run the following command:
    `terraform state mv 'module.eks.module.argo_cd[0].aws_acm_certificate.argocd_cert' 'module.eks.module.acm_certificates.aws_acm_certificate.certificates["argocd"]'`


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_name"></a> [account\_name](#input\_account\_name) | The AWS account name without the environment in it. By default the cluster\_name will be the account name so this should only be used when for some reason the account name does not match the cluster name. | `any` | `null` | no |
| <a name="input_ami_type"></a> [ami\_type](#input\_ami\_type) | AMI type for the node | `string` | `"BOTTLEROCKET_x86_64"` | no |
| <a name="input_ami_version"></a> [ami\_version](#input\_ami\_version) | AMi version for the AMI from which nodes are created | `string` | `"1.20.3-5d9ac849"` | no |
| <a name="input_application_argocd_addons_branch"></a> [application\_argocd\_addons\_branch](#input\_application\_argocd\_addons\_branch) | Git Repo Branch for Application ArgoCD configuration. | `string` | `""` | no |
| <a name="input_application_argocd_addons_path"></a> [application\_argocd\_addons\_path](#input\_application\_argocd\_addons\_path) | Git Repo Path for Application ArgoCD configuration. | `string` | `""` | no |
| <a name="input_application_argocd_addons_url"></a> [application\_argocd\_addons\_url](#input\_application\_argocd\_addons\_url) | Git Repo URL for Application ArgoCD configuration. | `string` | `""` | no |
| <a name="input_application_namespaces"></a> [application\_namespaces](#input\_application\_namespaces) | The names and configuration of the namespaces the application team require | <pre>map(object({<br/>    secrets_manager_access                 = optional(bool, false)<br/>    s3_bucket_names                        = optional(list(string), [])<br/>    bedrock_foundational_model_product_ids = optional(list(string), [])<br/>  }))</pre> | <pre>{<br/>  "app1": {<br/>    "bedrock_foundational_model_product_ids": [<br/>      "prod-ozonys2hmmpeu",<br/>      "prod-6dw3qvchef7zy"<br/>    ],<br/>    "s3_bucket_names": [<br/>      "test1",<br/>      "test2"<br/>    ],<br/>    "secrets_manager_access": true<br/>  },<br/>  "app2": {<br/>    "bedrock_foundational_model_product_ids": [<br/>      "prod-ozonys2hmmpeu",<br/>      "prod-6dw3qvchef7zy"<br/>    ],<br/>    "s3_bucket_names": [<br/>      "test1",<br/>      "test2"<br/>    ]<br/>  },<br/>  "app3": {<br/>    "secrets_manager_access": true<br/>  }<br/>}</pre> | no |
| <a name="input_argocd_creds_template_repo_url"></a> [argocd\_creds\_template\_repo\_url](#input\_argocd\_creds\_template\_repo\_url) | URL of the GitHub enterprise | `string` | `"https://github.com/TSB-Code"` | no |
| <a name="input_argocd_helm_version"></a> [argocd\_helm\_version](#input\_argocd\_helm\_version) | Helm chart version of ArgoCD | `string` | `"7.3.3"` | no |
| <a name="input_cert_manager_aws_pca_issuer_repo_url"></a> [cert\_manager\_aws\_pca\_issuer\_repo\_url](#input\_cert\_manager\_aws\_pca\_issuer\_repo\_url) | Docker image repository for aws-pca issuer cert-manager plug-in | `string` | `"public.ecr.aws/k1n1h4h4/cert-manager-aws-privateca-issuer"` | no |
| <a name="input_cert_manager_cainjector_replica_count"></a> [cert\_manager\_cainjector\_replica\_count](#input\_cert\_manager\_cainjector\_replica\_count) | Number of replicas for the cert-manager cainjector component | `number` | `1` | no |
| <a name="input_cert_manager_cainjector_repo_url"></a> [cert\_manager\_cainjector\_repo\_url](#input\_cert\_manager\_cainjector\_repo\_url) | Docker image repository for cert-manager cainjector | `string` | `"quay.io/jetstack/cert-manager-cainjector"` | no |
| <a name="input_cert_manager_controller_replica_count"></a> [cert\_manager\_controller\_replica\_count](#input\_cert\_manager\_controller\_replica\_count) | Number of replicas for the cert-manager controller component | `number` | `3` | no |
| <a name="input_cert_manager_controller_repo_url"></a> [cert\_manager\_controller\_repo\_url](#input\_cert\_manager\_controller\_repo\_url) | Docker image repository for cert-manager controller | `string` | `"quay.io/jetstack/cert-manager-controller"` | no |
| <a name="input_cert_manager_helm_version"></a> [cert\_manager\_helm\_version](#input\_cert\_manager\_helm\_version) | Helm chart version of the cert-manager chart | `string` | `"v1.16.0"` | no |
| <a name="input_cert_manager_release_name"></a> [cert\_manager\_release\_name](#input\_cert\_manager\_release\_name) | Helm release name for the cert-manager | `string` | `"cert-manager"` | no |
| <a name="input_cert_manager_service_account"></a> [cert\_manager\_service\_account](#input\_cert\_manager\_service\_account) | Service account name for the cert-manager | `string` | `"cert-manager"` | no |
| <a name="input_cert_manager_startupapicheck_repo_url"></a> [cert\_manager\_startupapicheck\_repo\_url](#input\_cert\_manager\_startupapicheck\_repo\_url) | Docker image repository for cert-manager startupapicheck | `string` | `"quay.io/jetstack/cert-manager-startupapicheck"` | no |
| <a name="input_cert_manager_webhook_replica_count"></a> [cert\_manager\_webhook\_replica\_count](#input\_cert\_manager\_webhook\_replica\_count) | Number of replicas for the cert-manager webhook component | `number` | `3` | no |
| <a name="input_cert_manager_webhook_repo_url"></a> [cert\_manager\_webhook\_repo\_url](#input\_cert\_manager\_webhook\_repo\_url) | Docker image repository for cert-manager webhook | `string` | `"quay.io/jetstack/cert-manager-webhook"` | no |
| <a name="input_certificate_authority_arn"></a> [certificate\_authority\_arn](#input\_certificate\_authority\_arn) | The AWS PCA for signing private certificates. | `string` | `"arn:aws:acm-pca:eu-west-2:091635179671:certificate-authority/c969bdd4-6f2c-4bc5-8ef3-de4382cef2ab"` | no |
| <a name="input_certificate_names"></a> [certificate\_names](#input\_certificate\_names) | List of certificate names to create under the dns\_domain | `list(string)` | `[]` | no |
| <a name="input_cloudwatch_version"></a> [cloudwatch\_version](#input\_cloudwatch\_version) | Addon version for the cloudwatch | `string` | `""` | no |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | A Custom name for the EKS cluster | `string` | n/a | yes |
| <a name="input_cluster_security_group_additional_rules"></a> [cluster\_security\_group\_additional\_rules](#input\_cluster\_security\_group\_additional\_rules) | Additional security group rules for the EKS cluster. | <pre>map(object({<br/>    description              = string<br/>    protocol                 = string<br/>    from_port                = number<br/>    to_port                  = number<br/>    type                     = string<br/>    source_security_group_id = string<br/>  }))</pre> | `{}` | no |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Kubernetes cluster version | `string` | `"1.30"` | no |
| <a name="input_coredns_version"></a> [coredns\_version](#input\_coredns\_version) | Addon version for the core-dns | `string` | `""` | no |
| <a name="input_custom_domain"></a> [custom\_domain](#input\_custom\_domain) | Custom domain to overwrite aws3.uk.tsb | `string` | `"aws3.uk.tsb"` | no |
| <a name="input_desired_size"></a> [desired\_size](#input\_desired\_size) | Desired number of nodes in the autoscaling group | `string` | n/a | yes |
| <a name="input_ebs_csi_driver_service_account_name"></a> [ebs\_csi\_driver\_service\_account\_name](#input\_ebs\_csi\_driver\_service\_account\_name) | Kubernetetes service account name for IRSA | `string` | `"ebs-csi-controller-sa"` | no |
| <a name="input_ebs_volume_size"></a> [ebs\_volume\_size](#input\_ebs\_volume\_size) | Size of the EBS volume for the nodes | `number` | `30` | no |
| <a name="input_enable_application_configuration"></a> [enable\_application\_configuration](#input\_enable\_application\_configuration) | Enable the functionality to create Namespaces and AppProjects for Applications | `bool` | `true` | no |
| <a name="input_enable_applications"></a> [enable\_applications](#input\_enable\_applications) | Whether to enable downstream application deployments. | `bool` | `false` | no |
| <a name="input_enable_argocd"></a> [enable\_argocd](#input\_enable\_argocd) | Flag to enable/disable argocd helm deployment | `bool` | `true` | no |
| <a name="input_enable_cert_manager"></a> [enable\_cert\_manager](#input\_enable\_cert\_manager) | # Cert-Manager | `bool` | `true` | no |
| <a name="input_enable_cloudwatch"></a> [enable\_cloudwatch](#input\_enable\_cloudwatch) | Flag to enable/disable the Cloudwatch Agent | `bool` | `false` | no |
| <a name="input_enable_ebs_csi_driver"></a> [enable\_ebs\_csi\_driver](#input\_enable\_ebs\_csi\_driver) | Flag to enable/disable the EBS CSI Driver | `bool` | `false` | no |
| <a name="input_enable_external_dns"></a> [enable\_external\_dns](#input\_enable\_external\_dns) | Flag to enable/disable External DNS | `bool` | `true` | no |
| <a name="input_enable_external_secrets"></a> [enable\_external\_secrets](#input\_enable\_external\_secrets) | Flag to enable/disable External Secrets | `bool` | `true` | no |
| <a name="input_enable_istio"></a> [enable\_istio](#input\_enable\_istio) | # Istio Service Mesh | `bool` | `false` | no |
| <a name="input_enable_lacework_admission_controller"></a> [enable\_lacework\_admission\_controller](#input\_enable\_lacework\_admission\_controller) | Enable Lacework Admission Controller on EKS cluster. | `bool` | `true` | no |
| <a name="input_enable_lacework_agent"></a> [enable\_lacework\_agent](#input\_enable\_lacework\_agent) | Enable Lacework Linux Agent on EKS cluster. | `bool` | `true` | no |
| <a name="input_enable_lb_controller"></a> [enable\_lb\_controller](#input\_enable\_lb\_controller) | Flag to enable/disable AWS Load Balancer controller helm deployment | `bool` | `true` | no |
| <a name="input_enable_metrics_server"></a> [enable\_metrics\_server](#input\_enable\_metrics\_server) | Flag to enable/disable metrics-server helm deployment | `bool` | `true` | no |
| <a name="input_enable_tactical_shared_imagepullsecret"></a> [enable\_tactical\_shared\_imagepullsecret](#input\_enable\_tactical\_shared\_imagepullsecret) | Enable the tactical ImagePullSecret functionality. This should only be used on advice from Platform Engineering. In order to use this the AWS Secrets Manager secret of jfrog-eks-tactical-imagepullsecret | `bool` | `true` | no |
| <a name="input_enable_vpc_custom_networking"></a> [enable\_vpc\_custom\_networking](#input\_enable\_vpc\_custom\_networking) | Enable VPC Custom Networking | `bool` | `false` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Type of environment. Can be sandbox, nonp or prod. | `string` | `"dev"` | no |
| <a name="input_external_dns_helm_version"></a> [external\_dns\_helm\_version](#input\_external\_dns\_helm\_version) | n/a | `string` | `"1.14.5"` | no |
| <a name="input_external_secrets_cluster_secret_store"></a> [external\_secrets\_cluster\_secret\_store](#input\_external\_secrets\_cluster\_secret\_store) | The name of the ClusterSecretStore | `string` | `"cluster-external-secretstore"` | no |
| <a name="input_external_secrets_cluster_secrets_namespace"></a> [external\_secrets\_cluster\_secrets\_namespace](#input\_external\_secrets\_cluster\_secrets\_namespace) | The name of the Kubernetes namespace for the ClusterSecretStore | `string` | `"cluster-secrets"` | no |
| <a name="input_external_secrets_cluster_service_account"></a> [external\_secrets\_cluster\_service\_account](#input\_external\_secrets\_cluster\_service\_account) | The name of the service account used for the ClusterSecretStore | `string` | `"cluster-external-secretstore"` | no |
| <a name="input_external_secrets_helm_version"></a> [external\_secrets\_helm\_version](#input\_external\_secrets\_helm\_version) | n/a | `string` | `"0.9.19"` | no |
| <a name="input_github_oidc_repositories"></a> [github\_oidc\_repositories](#input\_github\_oidc\_repositories) | List of GitHub repositories ArgoCD will need to access | `list(string)` | n/a | yes |
| <a name="input_github_oidc_role_attach_policies"></a> [github\_oidc\_role\_attach\_policies](#input\_github\_oidc\_role\_attach\_policies) | IAM policy ARN for ArgoCD to access GitHub repositories | `list(string)` | n/a | yes |
| <a name="input_instance_types"></a> [instance\_types](#input\_instance\_types) | Type of instance for the node group | `list(string)` | <pre>[<br/>  "m5.xlarge",<br/>  "m6i.xlarge",<br/>  "m6a.xlarge",<br/>  "r5.large",<br/>  "r6i.large"<br/>]</pre> | no |
| <a name="input_kube-proxy_version"></a> [kube-proxy\_version](#input\_kube-proxy\_version) | Addon version for the kube-proxy | `string` | `""` | no |
| <a name="input_kubernetes_pod_subnet_ids"></a> [kubernetes\_pod\_subnet\_ids](#input\_kubernetes\_pod\_subnet\_ids) | List of private subnets for Kubernetes pods to use. This feature is not ready. | `map(any)` | `{}` | no |
| <a name="input_lb_helm_version"></a> [lb\_helm\_version](#input\_lb\_helm\_version) | Helm chart version of the AWS LoadBalancer controller | `string` | `"1.8.1"` | no |
| <a name="input_lb_image_repo_url"></a> [lb\_image\_repo\_url](#input\_lb\_image\_repo\_url) | Docker image repository for AWS LoadBalancer controller to use in Helm deployment | `string` | `"337141981580.dkr.ecr.eu-west-2.amazonaws.com/tsb_sandbox1_ecr"` | no |
| <a name="input_lb_image_tag"></a> [lb\_image\_tag](#input\_lb\_image\_tag) | Docker image tag for the AWS LoadBalancer controller to use in Helm deployment | `string` | `"PVS_OB_BaseImage_lb_controller_v2.8.1latest"` | no |
| <a name="input_lb_replica_count"></a> [lb\_replica\_count](#input\_lb\_replica\_count) | Number of replicas for LoadBalancer controller | `number` | `1` | no |
| <a name="input_lb_service_account"></a> [lb\_service\_account](#input\_lb\_service\_account) | Name of the Kubernetes service account for the AWS Load Balancer Controller | `string` | `"aws-load-balancer-controller"` | no |
| <a name="input_max_size"></a> [max\_size](#input\_max\_size) | Mazximum number of nodes in the autoscaling group | `string` | n/a | yes |
| <a name="input_metrics_server_helm_chart_version"></a> [metrics\_server\_helm\_chart\_version](#input\_metrics\_server\_helm\_chart\_version) | Helm chart version of metrics-server | `string` | `"3.12.2"` | no |
| <a name="input_metrics_server_image_repo_url"></a> [metrics\_server\_image\_repo\_url](#input\_metrics\_server\_image\_repo\_url) | Docker image repository for metrics-server to use in Helm deployment | `string` | `"registry.k8s.io/metrics-server/metrics-server"` | no |
| <a name="input_metrics_server_image_tag"></a> [metrics\_server\_image\_tag](#input\_metrics\_server\_image\_tag) | Docker image tag for metrics-server to use in Helm deployment, defaults to appVersion of helm chart if left empty | `string` | `""` | no |
| <a name="input_metrics_server_replica_count"></a> [metrics\_server\_replica\_count](#input\_metrics\_server\_replica\_count) | Number of replicas for metrics-server | `number` | `3` | no |
| <a name="input_mgmt_cidrs"></a> [mgmt\_cidrs](#input\_mgmt\_cidrs) | n/a | `list(string)` | n/a | yes |
| <a name="input_min_size"></a> [min\_size](#input\_min\_size) | Minimum number of nodes in the autoscaling group | `string` | n/a | yes |
| <a name="input_node_security_group_additional_rules"></a> [node\_security\_group\_additional\_rules](#input\_node\_security\_group\_additional\_rules) | Additional security group rules for the EKS cluster nodes. | <pre>map(object({<br/>    description                   = string<br/>    protocol                      = string<br/>    from_port                     = number<br/>    to_port                       = number<br/>    type                          = string<br/>    source_cluster_security_group = bool<br/>  }))</pre> | `{}` | no |
| <a name="input_platform_argocd_addons_branch"></a> [platform\_argocd\_addons\_branch](#input\_platform\_argocd\_addons\_branch) | The branch of the Git epository hosting the ArgoCD bootstrap config for platform addons | `string` | `"refs/heads/main"` | no |
| <a name="input_platform_argocd_addons_url"></a> [platform\_argocd\_addons\_url](#input\_platform\_argocd\_addons\_url) | URL of the Git repository hosting the ArgoCD bootstrap config for platform addons | `string` | `"https://github.com/TSB-Code/AWS-AWS3-Platform-ArgoCD"` | no |
| <a name="input_principal_arns"></a> [principal\_arns](#input\_principal\_arns) | Principle ARN of the entity(user/role) for the admin access for the cluster | `list(string)` | `[]` | no |
| <a name="input_purchase_option"></a> [purchase\_option](#input\_purchase\_option) | Purchase option for the nodes | `string` | `"SPOT"` | no |
| <a name="input_region"></a> [region](#input\_region) | AWS region where resources are spinned up | `string` | n/a | yes |
| <a name="input_runner_cidrs"></a> [runner\_cidrs](#input\_runner\_cidrs) | n/a | `list(string)` | <pre>[<br/>  "10.160.4.0/24",<br/>  "10.160.5.0/24",<br/>  "10.160.6.0/24"<br/>]</pre> | no |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | List of private subnets | `list(string)` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags for the AWS resources to get added when the resources ois spinned up | `map(string)` | n/a | yes |
| <a name="input_vpc-cni_version"></a> [vpc-cni\_version](#input\_vpc-cni\_version) | Addon version for the VPC-CNI | `string` | `""` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | VPC id where all AWS resources will belong to | `string` | n/a | yes |
## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_acm_certificates"></a> [acm\_certificates](#module\_acm\_certificates) | ./modules/tf-aws-acm-certificates | n/a |
| <a name="module_application_bootstap"></a> [application\_bootstap](#module\_application\_bootstap) | ./modules/tf-aws-eks-application-bootstrap | n/a |
| <a name="module_argo_cd"></a> [argo\_cd](#module\_argo\_cd) | ./modules/tf-aws-argocd | n/a |
| <a name="module_aws_lb_controller"></a> [aws\_lb\_controller](#module\_aws\_lb\_controller) | ./modules/tf-aws-lb-controller | n/a |
| <a name="module_cert_manager"></a> [cert\_manager](#module\_cert\_manager) | ./modules/tf-aws-cert-manager | n/a |
| <a name="module_ebs_csi_driver"></a> [ebs\_csi\_driver](#module\_ebs\_csi\_driver) | ./modules/tf-aws-ebs-csi-driver | n/a |
| <a name="module_eks"></a> [eks](#module\_eks) | ./modules/tf-aws-eks-cluster | n/a |
| <a name="module_external_dns"></a> [external\_dns](#module\_external\_dns) | ./modules/tf-aws-external-dns | n/a |
| <a name="module_external_secrets"></a> [external\_secrets](#module\_external\_secrets) | ./modules/tf-aws-external-secrets | n/a |
## Outputs

No outputs.
## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.68.0 |
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | 5.68.0 |
| <a name="requirement_helm"></a> [helm](#requirement\_helm) | >=2.14 |
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | >= 2.31 |
## Resources

| Name | Type |
|------|------|
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/5.68.0/docs/data-sources/caller_identity) | data source |
| [aws_eks_addon_version.cloudwatch_agent_latest](https://registry.terraform.io/providers/hashicorp/aws/5.68.0/docs/data-sources/eks_addon_version) | data source |
| [aws_eks_addon_version.coredns_latest](https://registry.terraform.io/providers/hashicorp/aws/5.68.0/docs/data-sources/eks_addon_version) | data source |
| [aws_eks_addon_version.kube_proxy_latest](https://registry.terraform.io/providers/hashicorp/aws/5.68.0/docs/data-sources/eks_addon_version) | data source |
| [aws_eks_addon_version.vpc_cni_latest](https://registry.terraform.io/providers/hashicorp/aws/5.68.0/docs/data-sources/eks_addon_version) | data source |
| [aws_secretsmanager_secret_version.lacework_integration_access_token](https://registry.terraform.io/providers/hashicorp/aws/5.68.0/docs/data-sources/secretsmanager_secret_version) | data source | 