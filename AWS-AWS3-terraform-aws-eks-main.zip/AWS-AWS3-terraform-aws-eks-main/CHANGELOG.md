# 0.1.0
NEW FEATURES:
- AWS EKS cluster deployed at Kubernetes version 1.30 with managed node group of Bottlerocket
- ArgoCD Helm chart deployment for initial ArgoCD deployment onto cluster
- ArgoCD Platform specific addons bootstrap application deployed via Helm for ArgoCD bootstrap
- external-secrets IRSA role created for use with AWS Route53 and details passed to ArgoCD. Addon is then installed via ArgoCD
- external-dns IRSA role created for use with AWS Secrets Manager and details passed to ArgoCD. Addon is then installed via ArgoCD
- AWS Load Balancer Controller IRSA role created and details passed to ArgoCD. Addon is then installed via ArgoCD
- Initial connected tests using sit-bian account
- Istio installed via ArgoCD

EXPERIMENTS:
- Initial disconnected tests using SB2
- Lacework Linux agent installed via ArgoCD
- Lacework Admission Controller installed via ArgoCD
- Custom VPC networking enabled to have pods use secondary VPC CIDR range
