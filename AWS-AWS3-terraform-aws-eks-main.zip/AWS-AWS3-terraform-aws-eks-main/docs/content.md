# terraform-eks-module
## Introduction
This module is used to deploy a standard AWS EKS build. This will create an EKS cluster with ArgoCD installed. ArgoCD will then install cluster addons and also self manage ArgoCD. This module has been tested using the AWS-AWS3-Platform-ArgoCD repository for bootstrapping. Accessing ArgoCD can take between 5-15 minutes once the Terraform Apply has been successful. This allows suitable time for ArgoCD to bootstrap itself, create the AWS Load Balancer Controller and External-DNS. These resources are required to then allow ArgoCD to create an ingress which will then auto-discover the associated certificate for the AWS Application Load Balancer. Then it will add the appropriate Route53 record for ArgoCD. This time will then also give time for the hosted zones to propagate.

This module priortises doing Infrastructure via Terraform and using ArgoCD for cluster resources. This is enabled by Terraform doing 2 initial Helm releases. 1 is to install ArgoCD and the other is to install an ApplicationSet which then manages all of the ArgoCD addons. This is to keep as much of the Kubernetes configuration outside of Terrform. 

Addons are enabled within ArgoCD conditionally using the annotations of the cluster secret used to register the EKS cluster in ArgoCD. We use ArgoCD cluster generators to conditionally deploy addons to the EKS cluster dependent on whether the addons is enabled via these annotations.

There are a number of addons that depend on resources created via Terraform, i.e IRSA where Terraform will create the IAM role and a serviceaccount on the cluster needs the ARN. This functionality is performed by Terraform creating the AWS resources required and then storing the required information as labels  of the cluster secret used to register the EKS cluster in ArgoCD. ArgoCD ApplicationSets can then reference these values in their YAML manfiests.

The setting of annotations and labels is done using the local called `argocd`.

This Terraform module will only have submodules for products where we need to create some of their dependent resources using Terraform.

## Usage
This module is used by setting conditional boolean flags for functionality to be enabled. The products that can be enabled are:

- ArgoCD
- External-DNS
- External-Secrets
- AWS Load Balancer Controller
- Istio
- Laceworks
- Application Bootstrap
- Cert-manager
- Metrics-server

These can be enabled in your tfvars file by setting the enable values to `true`.

## Deletion
The deletion of this module is complicated due to the fact that ArgoCD will become responsible for creating AWS managed resources it means that deletion of this module depends on resources outside of its control. 

ArgoCD will use the AWS Load Balancer Controller to create a Kubernetes ingress. This will create an AWS Application Load Balancer. The ingress will also use External-DNS to create a Route53 record for the ingress. Unless these resources are destroyed in advance then this will leave resources left over and can prevent re-installing the same cluster.

We need someway of performing a cascading deletion of ArgoCD applications in the correct order before doing an automated deletion. Until then, we need to ensure that all of the AWS Application Load Balancers and Route53 records are deleted manually. This is required otherwise the ACM certificate cannot be deleted as there will be a Load Balancer still using the ACM cert.

## Upgrade instructions
- 0.6.0 to 0.7.0:
    - An engineer with access to the Terraform state will need to run the following command:
    `terraform state mv 'module.eks.module.argo_cd[0].aws_acm_certificate.argocd_cert' 'module.eks.module.acm_certificates.aws_acm_certificate.certificates["argocd"]'`