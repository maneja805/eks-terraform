#! /bin/bash
git clone https://github.com/OpenVPN/easy-rsa

cd easy-rsa/easyrsa3

./easyrsa init-pki

./easyrsa build-ca nopass

./easyrsa --san=DNS:server build-server-full server nopass

./easyrsa build-client-full client.vpn.tld nopass

mkdir ~/vpn/
cp pki/ca.crt ~/vpn/
cp pki/issued/server.crt ~/vpn/
cp pki/private/server.key ~/vpn/
cp pki/issued/client.vpn.tld.crt ~/vpn
cp pki/private/client.vpn.tld.key ~/vpn/
cd ~/vpn/

echo "Generating server cert..."
aws acm import-certificate --certificate fileb://server.crt --private-key fileb://server.key --certificate-chain fileb://ca.crt --tags Key=Type,Value=ServerCert

echo "Generating client VPN cert..."
aws acm import-certificate --certificate fileb://client.vpn.tld.crt --private-key fileb://client.vpn.tld.key --certificate-chain fileb://ca.crt --tags Key=Type,Value=ClientCert