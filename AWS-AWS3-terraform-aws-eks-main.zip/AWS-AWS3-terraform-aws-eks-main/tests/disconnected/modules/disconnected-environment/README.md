# Guide to creating a disconnected based environment

This pattern builds a VPC across 3 availability zones and with public and private subnets.  

https://tsbchange.atlassian.net/wiki/spaces/TA/pages/3531735041/Disconnected+environments+pattern

This pattern can only be deployed by default 5 times. This is due to needing an EIP and the account default limit is 5.

## Create the VPN certificates

The self signed certificates are created using easyrsa using the AWS CloudShell.  In CloudShell run the vpn-certs.sh script which is based upon the following page 

https://docs.aws.amazon.com/vpn/latest/clientvpn-admin/mutual.html

You will need to reply 'yes' to confirm the creation of keys.

The output ARN numbers should then be added into terraform.tfvars matching the server certificate to the variable *server_vpn_cert* and client certificate to *client_vpn_cert*

## Add the client VPN config
You will need to add your certificate and key to your ovpn config, like below:
cat ~/vpn/client.vpn.tld.crt
cat ~/vpn/client.vpn.tld.key
```
<cert>
-----BEGIN CERTIFICATE-----
[Your Client Certificate]
-----END CERTIFICATE-----
</cert>
<key>
-----BEGIN PRIVATE KEY-----
[Your Private Key]
-----END PRIVATE KEY-----
</key>
```

## Running the plan

Update all the variables in terraform.tfvars for your environment

Export the AWS keys for your OU to your environment (local or runner)

export AWS_ACCESS_KEY_ID="example"
export AWS_SECRET_ACCESS_KEY="example"
export AWS_SESSION_TOKEN="example"
